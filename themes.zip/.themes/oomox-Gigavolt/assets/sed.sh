#!/bin/sh
sed -i \
         -e 's/#2d303d/rgb(0%,0%,0%)/g' \
         -e 's/#ae94f9/rgb(100%,100%,100%)/g' \
    -e 's/#cad3ff/rgb(50%,0%,0%)/g' \
     -e 's/#40bfff/rgb(0%,50%,0%)/g' \
     -e 's/#2d303d/rgb(50%,0%,50%)/g' \
     -e 's/#e9e7e1/rgb(0%,0%,50%)/g' \
	"$@"
